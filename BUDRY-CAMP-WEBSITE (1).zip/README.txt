BUDRY CAMP WEBSITE

1. Open index.html to preview the site.
2. Before publishing, edit the Contact section in index.html and add the camp phone/WhatsApp and email.
3. Upload the entire contents of this folder to a static web host.
4. The site needs no database and no paid software.
